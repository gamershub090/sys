import java.rmi.RemoteException; import java.rmi.server.UnicastRemoteObject;
public class AdderImpl extends UnicastRemoteObject implements Adder {
 private static final long serialVersionUID = 1L;
 public AdderImpl() throws RemoteException { super(); }
 public int add(int a,int b){return a+b;} public int subtract(int a,int b){return a-b;}
 public int multiply(int a,int b){return a*b;} public double divide(int a,int b){if(b==0)throw new ArithmeticException("Division by zero");return (double)a/b;}
}
