import java.rmi.registry.LocateRegistry; import java.rmi.registry.Registry;
public class RMIServer { public static void main(String[] args){try{Registry r=LocateRegistry.createRegistry(1099);r.rebind("AdderService",new AdderImpl());System.out.println("RMI server ready on port 1099");}catch(Exception e){e.printStackTrace();}} }
