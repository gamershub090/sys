Compile: javac *.java
Terminal 1: java RMIServer
Terminal 2: java RMIClient
The registry is created by RMIServer on port 1099. Run both terminals in this folder.
