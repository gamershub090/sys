Compile/run: javac ClockSynchronization.java && java ClockSynchronization
Demonstrates Lamport logical receive rule, Cristian midpoint-delay correction, and Berkeley average-offset calculation. This is an algorithm demonstration, not the complete DFS socket/file-service implementation shown in the longer practical report.
