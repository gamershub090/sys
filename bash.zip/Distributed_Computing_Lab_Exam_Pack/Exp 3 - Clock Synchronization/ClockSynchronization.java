import java.util.*;
public class ClockSynchronization {
 static long lamport=0; static long receive(long incoming){lamport=Math.max(lamport,incoming)+1;return lamport;}
 static long cristianOffset(long serverMillis,long t0,long t1){return serverMillis-(t0+t1)/2;}
 static long[] berkeleyOffsets(long[] clocks){long sum=0;for(long x:clocks)sum+=x;long avg=Math.round((double)sum/clocks.length);long[] d=new long[clocks.length];for(int i=0;i<d.length;i++)d[i]=avg-clocks[i];return d;}
 public static void main(String[] args){System.out.println("LAMPORT LOGICAL CLOCK");long send=++lamport;System.out.println("P1 sends timestamp "+send);System.out.println("P2 receives; updated clock="+receive(send));
 long t0=1000,server=1500,t1=1100;System.out.println("\nCRISTIAN: estimated offset="+cristianOffset(server,t0,t1)+" ms (illustrative clock units)");
 long[] clocks={1000,1100,900};long[] offsets=berkeleyOffsets(clocks);System.out.println("\nBERKELEY: clocks="+Arrays.toString(clocks));System.out.println("Adjustments="+Arrays.toString(offsets));}
}
