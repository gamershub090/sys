Compile: javac *.java
Terminal 1-3: java ServerNode 1 6001  (repeat for IDs 2/3 and ports 6002/6003)
Terminal 4: java LoadBalancer
Terminal 5: java LoadBalancingClient
Least-load policy uses outstanding MB; servers simulate processing at 50 MB/s.
