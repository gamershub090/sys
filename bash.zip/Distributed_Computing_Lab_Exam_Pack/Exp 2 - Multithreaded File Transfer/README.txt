Compile: javac *.java
Terminal 1: java Server
Terminal 2 (repeat in another terminal for concurrency): java Client; enter path to a file. Files appear in uploads/.
