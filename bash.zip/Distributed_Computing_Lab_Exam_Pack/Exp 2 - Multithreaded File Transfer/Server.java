import java.io.*;import java.net.*;
public class Server {public static final int PORT=5001;public static void main(String[] a){try(ServerSocket ss=new ServerSocket(PORT)){System.out.println("Upload server on "+PORT);while(true){Socket s=ss.accept();new Thread(new ClientHandler(s)).start();}}catch(IOException e){e.printStackTrace();}}}
