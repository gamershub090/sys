Compile/run: javac ElectionAlgorithms.java && java ElectionAlgorithms
Edit the active-node list in main to simulate failures. Both algorithms elect the highest active ID; this is a deterministic algorithm simulation rather than a multi-host TCP implementation.
