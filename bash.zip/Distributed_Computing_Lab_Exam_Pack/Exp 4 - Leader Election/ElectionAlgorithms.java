import java.util.*;
public class ElectionAlgorithms {
 static int bully(List<Integer> alive,int initiator){int winner=-1;for(int id:alive)winner=Math.max(winner,id);System.out.println("Bully election initiated by "+initiator+"; highest active ID wins: "+winner);return winner;}
 static int ring(List<Integer> ring,int initiator){List<Integer> active=new ArrayList<>(ring);if(!active.contains(initiator))throw new IllegalArgumentException("Initiator is down");int start=active.indexOf(initiator),max=-1;for(int k=0;k<active.size();k++){int id=active.get((start+k)%active.size());System.out.println("ELECTION message visits node "+id);max=Math.max(max,id);}System.out.println("COORDINATOR announcement: node "+max);return max;}
 public static void main(String[] args){List<Integer> alive=Arrays.asList(1,2,4,5);bully(alive,2);System.out.println("--- Ring ---");ring(alive,2);}
}
