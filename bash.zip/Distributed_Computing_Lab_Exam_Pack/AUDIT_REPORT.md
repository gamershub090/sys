# Distributed Computing Lab — Code Audit

## Scope
The uploaded practicals and companion material were reviewed for Experiments 1–10. Duplicate uploads were treated as supporting/alternate copies, not separate experiments. The pack contains cleaned implementations named after their experiment and source role.

## Per-experiment review

| Exp. | Included code | Review / validation |
|---|---|---|
| 1 | Java RMI: `Adder`, `AdderImpl`, `RMIServer`, `RMIClient` | Compiled with Java. RMI server creates registry on 1099; client performs the four arithmetic operations. End-to-end local test passed (8 + 2 = 10). |
| 2 | Java socket upload: `Server`, `ClientHandler`, `Client` | Compiled with Java. Uses one thread per client, length-prefixed file transfer, chunked reads, and a sanitized basename. End-to-end upload and byte-for-byte comparison passed. |
| 3 | `ClockSynchronization.java` | Compiled and ran. Demonstrates Lamport receive rule, Cristian's midpoint/round-trip estimate, and Berkeley average-offset adjustment. This is a focused algorithm demonstration, not the full DFS file-service/socket application from the longer report. |
| 4 | `ElectionAlgorithms.java` | Compiled and ran. Demonstrates Bully and Ring elections over an editable active-node set; both elect the highest active ID. This is a deterministic algorithm simulation, not a multi-host TCP node implementation. |
| 5 | `ReplicationDemo.java` | Compiled and ran. Shows a stale-read interval followed by passive replica convergence, and ordered active replication to all replicas. It is an in-memory model, not a networked key-value store. |
| 6 | `ServerNode`, `LoadBalancer`, `LoadBalancingClient` | All Java sources compiled. Corrected the source filename/class-name mismatches present in the handwritten listing; least-outstanding-MB selection and 50 MB/s simulated processing are implemented. Multi-server runtime test was not performed. |
| 7 | Word count plus five Spark problem programs and their input datasets | All Python files passed syntax compilation. Each implements the described RDD transformations: word count, line lengths, max temperature by city, stopword-filtered counts, student averages, and hashtag frequency. Spark runtime could not be exercised because PySpark is not installed in this environment. |
| 8 | `backup_server.py`, `primary_server.py`, `client.py` | Python syntax check passed. In-process socket smoke test confirmed primary GET/INCREMENT, synchronous replication acknowledgement, and the backup serving the replicated value. Full separate-terminal Ctrl+C failover sequence was not run end-to-end. |
| 9 | Main collective program plus five MPI problem programs | All Python files passed syntax compilation. Implements broadcast/scatter/gather, reduce sum, matrix addition, square-and-gather, gather+broadcast vs allgather, and point-to-point vs buffer Bcast timing. MPI runtime could not be exercised because mpi4py and mpirun/mpiexec are unavailable here. |
| 10 | Main matrix multiplication plus six extensions | All Python files passed syntax compilation. Uses `array_split` for uneven row distribution, broadcast, gather, reduce, and serial NumPy correctness checks. MPI runtime could not be exercised because mpi4py and mpirun/mpiexec are unavailable here. |

## Important corrections / caveats

- Experiment 2's original style of directly using a client-provided filename can permit path traversal. The supplied version strips directory components before saving.
- Experiment 6's handwritten filenames did not match their public Java class names; Java requires matching filenames. The pack uses `ServerNode.java`, `LoadBalancer.java`, and `LoadBalancingClient.java`.
- Spark `saveAsTextFile` fails if its output directory already exists. The word-count program writes to `output_wordcount/` to avoid colliding with a generic prior `output/` directory; remove that folder before rerunning if it already exists.
- Experiments 3–5 are intentionally compact, self-contained demonstrations of the stated algorithms. They should not be represented as full distributed deployments.
- Experiments 7, 9 and 10 need their respective runtimes installed. Syntax validity alone does not prove a Spark job or multi-rank MPI job executes correctly on the exam machine.

## Test summary

- Java compilation: Experiments 1–6 — passed.
- Java runtime smoke tests: Experiments 3–5 — passed.
- Java RMI end-to-end: Experiment 1 — passed.
- Java socket file upload: Experiment 2 — passed.
- Python syntax compilation: all Python files in Experiments 7–10 — passed.
- Experiment 8 socket smoke test: primary/backup read and update replication — passed.
- PySpark runtime: not run (PySpark unavailable).
- MPI runtime: not run (mpi4py and MPI launcher unavailable).
