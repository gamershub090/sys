import java.util.*;
public class ReplicationDemo {
 static class Store {String value="v1";int version=1;void put(String v){value=v;version++;}String read(){return "v"+version+"="+value;}}
 static void passive(){Store p=new Store(),r1=new Store(),r2=new Store();System.out.println("PASSIVE / EVENTUAL CONSISTENCY");p.put("updated");System.out.println("Immediately: primary="+p.read()+", replica1="+r1.read());r1.value=p.value;r1.version=p.version;r2.value=p.value;r2.version=p.version;System.out.println("After propagation: "+p.read()+" | "+r1.read()+" | "+r2.read());}
 static void active(){Store[] replicas={new Store(),new Store(),new Store()};String[] ops={"alpha","beta","gamma"};int seq=0;for(String v:ops){seq++;for(Store s:replicas){s.value=v;s.version=seq;}}System.out.println("ACTIVE / ORDERED REPLICATION");for(int i=0;i<replicas.length;i++)System.out.println("Replica "+i+": "+replicas[i].read());}
 public static void main(String[] a){passive();active();}
}
