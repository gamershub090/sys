Compile/run: javac ReplicationDemo.java && java ReplicationDemo
Passive mode deliberately shows a stale-read window before replica propagation. Active mode applies the same sequenced operations to every replica in the same order.
