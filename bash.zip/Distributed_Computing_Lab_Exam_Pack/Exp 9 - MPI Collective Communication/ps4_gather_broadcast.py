from mpi4py import MPI
c=MPI.COMM_WORLD;r=c.Get_rank();value=(r+1)*100
collected=c.gather(value,root=0);manual=c.bcast(collected,root=0);all_values=c.allgather(value)
print(f"[Rank {r}] gather+bcast={manual} | allgather={all_values} | match={manual==all_values}",flush=True)
