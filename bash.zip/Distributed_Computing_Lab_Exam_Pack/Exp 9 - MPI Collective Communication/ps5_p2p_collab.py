from mpi4py import MPI
import numpy as np
c=MPI.COMM_WORLD;r=c.Get_rank();n=c.Get_size();N=1_000_000;REPEAT=5
buf=np.arange(N,dtype='d') if r==0 else np.empty(N,dtype='d')
c.Barrier();t=MPI.Wtime()
for _ in range(REPEAT):
 if r==0:
  for dest in range(1,n):c.Send(buf,dest=dest,tag=11)
 else:c.Recv(buf,source=0,tag=11)
c.Barrier();p2p=(MPI.Wtime()-t)/REPEAT
c.Barrier();t=MPI.Wtime()
for _ in range(REPEAT):c.Bcast(buf,root=0)
c.Barrier();bcast=(MPI.Wtime()-t)/REPEAT
if r==0:print(f"Average seconds: point-to-point={p2p:.6f}, Bcast={bcast:.6f}; speed ratio={p2p/bcast if bcast else float('inf'):.2f}x")
