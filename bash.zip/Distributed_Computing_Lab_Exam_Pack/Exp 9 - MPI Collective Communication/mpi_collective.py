from mpi4py import MPI
comm=MPI.COMM_WORLD;rank=comm.Get_rank();size=comm.Get_size()
message="Hello MPI Processes!" if rank==0 else None
message=comm.bcast(message,root=0);print(f"[Rank {rank}] Received broadcast data: {message}",flush=True)
values=[i*10 for i in range(size)] if rank==0 else None
local=comm.scatter(values,root=0);print(f"[Rank {rank}] Received scatter value: {local}",flush=True)
result=comm.gather(local+rank,root=0)
if rank==0:print(f"[Rank 0] Gathered data from all processes: {result}",flush=True)
