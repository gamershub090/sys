from mpi4py import MPI
c=MPI.COMM_WORLD;r=c.Get_rank();n=c.Get_size();data=[i*10 for i in range(n)] if r==0 else None
local=c.scatter(data,root=0)+r;total=c.reduce(local,op=MPI.SUM,root=0)
print(f"[Rank {r}] Local value: {local}",flush=True)
if r==0:print(f"[Rank 0] Sum of local values: {total}",flush=True)
