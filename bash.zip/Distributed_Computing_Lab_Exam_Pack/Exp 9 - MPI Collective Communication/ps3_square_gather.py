from mpi4py import MPI
import numpy as np
c=MPI.COMM_WORLD;r=c.Get_rank();n=c.Get_size()
if r==0:values=list(range(2,10));chunks=[list(x) for x in np.array_split(values,n)]
else:chunks=None
mine=c.scatter(chunks,root=0);pairs=[(x,x*x) for x in mine];parts=c.gather(pairs,root=0)
if r==0:
 flat=sorted(pair for part in parts for pair in part);print("Squares:",[v for _,v in flat])
