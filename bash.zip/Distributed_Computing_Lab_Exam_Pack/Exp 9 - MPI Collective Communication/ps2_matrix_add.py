from mpi4py import MPI
import numpy as np
c=MPI.COMM_WORLD;r=c.Get_rank();n=c.Get_size()
if r==0:
 A=np.arange(1,17).reshape(4,4);B=np.full((4,4),10);ac=np.array_split(A,n);bc=np.array_split(B,n)
else:A=B=ac=bc=None
x=c.scatter(ac,root=0);y=c.scatter(bc,root=0);local=x+y;parts=c.gather(local,root=0)
if r==0:
 C=np.vstack(parts);print("A+B:\n",C);print("Correct:",np.array_equal(C,A+B))
