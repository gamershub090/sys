import socket,threading
HOST="127.0.0.1";REPLICATION_PORT=5001;SERVICE_PORT=5002
counter=0;lock=threading.Lock()
def send(f,msg):f.write((msg+"\n").encode());f.flush()
def replication(conn,addr):
 global counter
 with conn,conn.makefile("rwb") as f:
  for raw in f:
   msg=raw.decode().strip()
   if msg.startswith("STATE "):
    try:
     value=int(msg.split()[1])
     with lock:counter=value
     send(f,"BACKUP_READY")
     print("[BACKUP] Replicated",value,flush=True)
    except ValueError:send(f,"ERROR invalid state")
def service(conn,addr):
 global counter
 with conn,conn.makefile("rwb") as f:
  for raw in f:
   cmd=raw.decode().strip().upper()
   if cmd=="GET":
    with lock:v=counter
    send(f,f"VALUE counter={v}")
   elif cmd=="INCREMENT":
    with lock:counter+=1;v=counter
    send(f,f"OK counter={v}")
   elif cmd=="QUIT":send(f,"BYE");break
   else:send(f,"ERROR unknown command")
def listener(port,handler):
 with socket.socket() as s:
  s.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1);s.bind((HOST,port));s.listen();print(f"[BACKUP] Listening on {port}",flush=True)
  while True:
   c,a=s.accept();threading.Thread(target=handler,args=(c,a),daemon=True).start()
if __name__=="__main__":
 threading.Thread(target=listener,args=(REPLICATION_PORT,replication),daemon=True).start();listener(SERVICE_PORT,service)
