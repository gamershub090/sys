import socket
HOST="127.0.0.1";PRIMARY=5000;BACKUP=5002
def connect(port):
 s=socket.create_connection((HOST,port),timeout=3);return s,s.makefile("rwb")
def main():
 port=PRIMARY;s=None;f=None
 while True:
  try:
   if s is None:s,f=connect(port);print(f"[CLIENT] Connected to {port}")
   cmd=input("GET / INCREMENT / QUIT: ").strip().upper()
   if cmd not in {"GET","INCREMENT","QUIT"}:print("Invalid command");continue
   f.write((cmd+"\n").encode());f.flush();reply=f.readline().decode().strip()
   if not reply:raise ConnectionError("server disconnected")
   print(reply)
   if cmd=="QUIT":break
  except (OSError,ConnectionError,TimeoutError) as e:
   print("[CLIENT] Primary unavailable:",e)
   if s:
    try:f.close();s.close()
    except OSError:pass
   s=f=None
   if port==PRIMARY:
    port=BACKUP;print("[CLIENT] Switching to promoted backup on 5002")
   else:print("[CLIENT] Backup unavailable; restart when service is ready")

 if f:f.close()
 if s:s.close()
if __name__=="__main__":main()
