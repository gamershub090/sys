import socket,threading
HOST="127.0.0.1";CLIENT_PORT=5000;BACKUP_PORT=5001;counter=0;lock=threading.Lock()
def send_line(f,msg):f.write((msg+"\n").encode());f.flush()
def replicate(value):
 with socket.create_connection((HOST,BACKUP_PORT),timeout=3) as s,s.makefile("rwb") as f:
  send_line(f,f"STATE {value}");reply=f.readline().decode().strip()
  if reply!="BACKUP_READY":raise ConnectionError("Backup did not acknowledge: "+reply)
def handle(c,a):
 global counter
 with c,c.makefile("rwb") as f:
  for raw in f:
   cmd=raw.decode().strip().upper()
   if cmd=="GET":
    with lock:v=counter
    send_line(f,f"VALUE counter={v}")
   elif cmd=="INCREMENT":
    with lock:
     candidate=counter+1
     try:replicate(candidate)
     except OSError as e:send_line(f,"ERROR replication failed: "+str(e));continue
     counter=candidate
    send_line(f,f"OK counter={counter}")
   elif cmd=="QUIT":send_line(f,"BYE");break
   else:send_line(f,"ERROR unknown command")
def main():
 global counter
 try:replicate(counter)
 except OSError as e:raise SystemExit("Start backup_server.py first: "+str(e))
 with socket.socket() as s:
  s.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1);s.bind((HOST,CLIENT_PORT));s.listen();print("[PRIMARY] Listening on",CLIENT_PORT,flush=True)
  while True:
   c,a=s.accept();threading.Thread(target=handle,args=(c,a),daemon=True).start()
if __name__=="__main__":main()
