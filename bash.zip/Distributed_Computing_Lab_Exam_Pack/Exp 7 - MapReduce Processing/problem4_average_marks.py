from pyspark import SparkContext
def parse(line):
 student,subject,mark=line.split(",");return student,(float(mark),1)
def combine(a,b):return a[0]+b[0],a[1]+b[1]
def main():
 sc=SparkContext.getOrCreate();sc.setLogLevel("WARN")
 try:
  totals=sc.textFile("marks.txt").map(parse).reduceByKey(combine)
  for student,(total,n) in sorted(totals.collect()):print(f"{student}: {total/n:.2f}")
 finally:sc.stop()
if __name__=="__main__":main()
