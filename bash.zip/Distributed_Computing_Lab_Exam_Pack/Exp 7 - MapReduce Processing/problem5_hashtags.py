from pyspark import SparkContext
def main():
 sc=SparkContext.getOrCreate();sc.setLogLevel("WARN")
 try:
  tags=(sc.textFile("tweets.txt").flatMap(lambda line:line.split()).filter(lambda w:w.startswith("#")).map(lambda w:(w.lower().strip(".,!?;:"),1)).reduceByKey(lambda a,b:a+b))
  for tag,n in sorted(tags.collect()):print(f"{tag}: {n}")
 finally:sc.stop()
if __name__=="__main__":main()
