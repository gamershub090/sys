from pyspark import SparkContext

def main():
    sc=SparkContext.getOrCreate(); sc.setLogLevel("WARN")
    try:
        counts=sc.textFile("input.txt").flatMap(lambda x:x.split()).map(lambda w:(w,1)).reduceByKey(lambda a,b:a+b)
        for word,count in sorted(counts.collect()): print(f"{word} {count}")
        counts.saveAsTextFile("output_wordcount")
    finally: sc.stop()
if __name__=="__main__": main()
