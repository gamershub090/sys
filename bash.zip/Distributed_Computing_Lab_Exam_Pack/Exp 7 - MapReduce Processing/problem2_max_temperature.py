from pyspark import SparkContext
def parse(line):
 city,temp=line.rsplit(",",1);return city.strip(),float(temp)
def main():
 sc=SparkContext.getOrCreate();sc.setLogLevel("WARN")
 try:
  result=sc.textFile("temperature.txt").map(parse).reduceByKey(max).collect()
  for city,temp in sorted(result):print(f"{city}: {temp:.1f}°C")
 finally:sc.stop()
if __name__=="__main__":main()
