from pyspark import SparkContext
STOPWORDS={"the","is","a","an","this"}
def main():
 sc=SparkContext.getOrCreate();sc.setLogLevel("WARN")
 try:
  counts=(sc.textFile("stopword_input.txt").flatMap(lambda x:x.lower().split()).filter(lambda w:w not in STOPWORDS).map(lambda w:(w,1)).reduceByKey(lambda a,b:a+b))
  for word,count in sorted(counts.collect()):print(f"{word}: {count}")
 finally:sc.stop()
if __name__=="__main__":main()
