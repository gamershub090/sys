from pyspark import SparkContext
def main():
 sc=SparkContext.getOrCreate();sc.setLogLevel("WARN")
 try:
  lengths=sc.textFile("input.txt").map(len); vals=lengths.collect(); total=sum(vals); count=len(vals)
  print("Line lengths:",vals);print("Number of lines:",count);print("Total characters:",total);print("Average line length:",round(total/count,2) if count else 0)
 finally:sc.stop()
if __name__=="__main__":main()
