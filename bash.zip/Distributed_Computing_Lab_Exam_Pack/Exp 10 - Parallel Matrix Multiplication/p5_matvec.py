from mpi4py import MPI
import numpy as np
c=MPI.COMM_WORLD;r=c.Get_rank();n=c.Get_size()
if r==0:A=np.array([[1,2,3,4],[4,3,2,1],[1,1,1,1],[2,2,2,2]]);x=np.array([1,0,2,1]);chunks=np.array_split(A,n,axis=0)
else:A=x=chunks=None
local_A=c.scatter(chunks,root=0);x=c.bcast(x,root=0);parts=c.gather(local_A@x,root=0)
if r==0:y=np.concatenate(parts);print("y=A@x:",y);print("Correct:",np.array_equal(y,A@x))
