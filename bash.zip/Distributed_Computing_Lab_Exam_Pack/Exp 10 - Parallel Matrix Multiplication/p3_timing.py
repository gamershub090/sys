from mpi4py import MPI
import numpy as np,sys
c=MPI.COMM_WORLD;r=c.Get_rank();nproc=c.Get_size();N=int(sys.argv[1]) if len(sys.argv)>1 else 400
if r==0:rng=np.random.default_rng(42);A=rng.random((N,N));B=rng.random((N,N));chunks=np.array_split(A,nproc,axis=0)
else:A=B=chunks=None
c.Barrier();t0=MPI.Wtime();local_A=c.scatter(chunks,root=0);B=c.bcast(B,root=0);t1=MPI.Wtime();local_C=local_A@B;t2=MPI.Wtime();parts=c.gather(local_C,root=0);c.Barrier();t3=MPI.Wtime();max_compute=c.reduce(t2-t1,op=MPI.MAX,root=0)
if r==0:C=np.vstack(parts);print(f"N={N}, processes={nproc}, total={t3-t0:.4f}s, max_compute={max_compute:.4f}s, correct={np.allclose(C,A@B)}")
