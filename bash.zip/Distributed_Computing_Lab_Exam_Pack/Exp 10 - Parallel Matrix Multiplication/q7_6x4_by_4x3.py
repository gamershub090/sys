from mpi4py import MPI
import numpy as np
c=MPI.COMM_WORLD;r=c.Get_rank();nproc=c.Get_size();m,n,p=6,4,3
if r==0:A=np.arange(1,m*n+1).reshape(m,n);B=np.arange(1,n*p+1).reshape(n,p);chunks=np.array_split(A,nproc,axis=0)
else:A=B=chunks=None
local_A=c.scatter(chunks,root=0);B=c.bcast(B,root=0);parts=c.gather(local_A@B,root=0)
if r==0:C=np.vstack(parts);print("C=A@B:\n",C);print("Correct:",np.array_equal(C,A@B))
