from mpi4py import MPI
import numpy as np
c=MPI.COMM_WORLD;r=c.Get_rank();n=c.Get_size()
if r==0:A=np.array([[1,2,3,4],[4,3,2,1],[1,1,1,1],[2,2,2,2]]);B=np.array([[1,0,2,1],[0,1,1,0],[1,1,0,1],[2,1,1,2]]);chunks=np.array_split(A,n,axis=0)
else:A=B=chunks=None
local_A=c.scatter(chunks,root=0);B=c.bcast(B,root=0);local_sum=int((local_A@B).sum());total=c.reduce(local_sum,op=MPI.SUM,root=0)
if r==0:print("Sum via reduce:",total);print("Serial check:",int((A@B).sum()))
