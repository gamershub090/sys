DISTRIBUTED COMPUTING LAB EXAM PACK — Experiments 01–10

Each Experiment_XX folder contains source files and a README with run instructions. The code is a cleaned, corrected implementation of the operations described in the uploaded practicals.

Environment: Java 21 for Experiments 1,2,3,4,5,6; Python + PySpark for Experiment 7; Python sockets for Experiment 8; mpi4py + NumPy + MPICH/Open MPI for Experiments 9 and 10.

Audit limitations: Java sources are compiled; Python sources are syntax-checked. Spark/MPI runtime execution requires those dependencies and a functioning local JVM/MPI installation. For multi-process behaviour, run the commands in each folder README.

Experiment 3 and 4 are compact algorithm demonstrations (clock synchronization and election), not the full socket-based DFS application in the long report. Experiment 4 demonstrates both algorithms and allows changing active IDs. Experiment 8 implements synchronous primary-backup state replication and client failover; backup promotion is manual-by-client-failover, not consensus-based automatic election.
